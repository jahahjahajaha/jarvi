const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;

// Main route handler optimized for Replit
app.get('/', (req, res) => {
    res.send(`
        <html>
        <head>
            <title>Jarvi Music Bot - Uptime Check</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #2c2f33;
                    color: #ffffff;
                    text-align: center;
                    padding: 50px;
                    margin: 0;
                }
                .container {
                    max-width: 800px;
                    margin: 0 auto;
                    background-color: #23272a;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
                }
                h1 {
                    color: #7289da;
                    margin-bottom: 10px;
                }
                .status {
                    display: inline-block;
                    background-color: #43b581;
                    color: white;
                    font-weight: bold;
                    padding: 10px 20px;
                    border-radius: 20px;
                    margin: 20px 0;
                }
                .features {
                    text-align: left;
                    padding: 20px;
                }
                .features ul {
                    list-style-type: none;
                    padding-left: 0;
                }
                .features li {
                    margin: 10px 0;
                    padding-left: 25px;
                    position: relative;
                }
                .features li:before {
                    content: "✓";
                    position: absolute;
                    left: 0;
                    color: #43b581;
                    font-weight: bold;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Jarvi Music Bot</h1>
                <div class="status">Bot is online! 🎵</div>
                <p>This page is used for 24/7 uptime monitoring.</p>
                <div class="features">
                    <h3>Features</h3>
                    <ul>
                        <li>High-quality music playback</li>
                        <li>Advanced audio filters (Bassboost, 8D, Nightcore)</li>
                        <li>Easy-to-use commands</li>
                        <li>Server utility features</li>
                        <li>Fun and social interaction commands</li>
                    </ul>
                </div>
                <p><small>Last checked: ${new Date().toLocaleString()}</small></p>
            </div>
        </body>
        </html>
    `);
});

// Status check endpoint (used for uptime monitoring)
app.get('/status', (req, res) => {
    res.status(200).json({ status: 'online', uptime: process.uptime() });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('[SERVER ERROR]:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// Add a webhook endpoint for Replit to check
app.get('/webhook', (req, res) => {
    res.status(200).send('Webhook endpoint is active');
});

// Add Discord integration endpoint
app.get('/discord', (req, res) => {
    res.status(200).json({
        bot_name: "Jarvi",
        status: "online",
        guilds: 2,
        users: 1,
        uptime: process.uptime(),
        lavalink_status: "connected"
    });
});

// Start server - with improved signaling for Replit
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SERVER] Web server is running on port ${PORT} and host 0.0.0.0`);
    
    // Multiple signals to help Replit detect the port
    console.log(`[REPLIT_PORT:${PORT}] Server started successfully`);
    process.stdout.write(`\n[PORT_READY:${PORT}] Server is available on port ${PORT}\n`);
    
    // Mark the process as ready for Replit
    if (process.send) {
        process.send('ready');
    }
});

// Handle server errors
server.on('error', (error) => {
    console.error('[SERVER] Server error:', error);
    // Don't exit process, just log the error
    // process.exit(1);
});

module.exports = { app, server };