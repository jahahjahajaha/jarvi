const express = require('express');
const app = express();
const PORT = 5000;

app.get('/', (req, res) => {
    res.send('Test server running');
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Test server listening on port ${PORT} and host 0.0.0.0`);
}).on('error', (error) => {
    console.error('Failed to start test server:', error);
});
