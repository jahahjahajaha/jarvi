// Top level index file to start the Discord bot
// This is a simple wrapper to start the bot from the root folder

// Import and run the bot
require('./src/index.js');